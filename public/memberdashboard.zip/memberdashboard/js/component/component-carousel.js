/*! For license information please see component-carousel.js.LICENSE.txt */
"use strict";document.addEventListener("DOMContentLoaded",(function(){swipernav()}));